import AppKit

var str = "Hello, playground"
